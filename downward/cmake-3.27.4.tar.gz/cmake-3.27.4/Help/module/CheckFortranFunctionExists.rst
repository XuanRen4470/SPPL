.. cmake-module:: ../../Modules/CheckFortranFunctionExists.cmake
